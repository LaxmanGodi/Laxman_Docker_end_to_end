/*
Copyright 2021 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package controllertest

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
)

var _ runtime.Object = &UnconventionalListType{}
var _ runtime.Object = &UnconventionalListTypeList{}

// UnconventionalListType is used to test CRDs with List types that
// have a slice of pointers rather than a slice of literals.
type UnconventionalListType struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`
	Spec              string `json:"spec,omitempty"`
}

// DeepCopyObject implements runtime.Object
// Handwritten for simplicity.
func (u *UnconventionalListType) DeepCopyObject() runtime.Object {
	return u.DeepCopy()
}

// DeepCopy implements *UnconventionalListType
// Handwritten for simplicity.
func (u *UnconventionalListType) DeepCopy() *UnconventionalListType {
	return &UnconventionalListType{
		TypeMeta:   u.TypeMeta,
		ObjectMeta: *u.ObjectMeta.DeepCopy(),
		Spec:       u.Spec,
	}
}

// UnconventionalListTypeList is used to test CRDs with List types that
// have a slice of pointers rather than a slice of literals.
type UnconventionalListTypeList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []*UnconventionalListType `json:"items"`
}

// DeepCopyObject implements runtime.Object
// Handwritten for simplicity.
func (u *UnconventionalListTypeList) DeepCopyObject() runtime.Object {
	return u.DeepCopy()
}

// DeepCopy implements *UnconventionalListTypeListt
// Handwritten for simplicity.
func (u *UnconventionalListTypeList) DeepCopy() *UnconventionalListTypeList {
	out := &UnconventionalListTypeList{
		TypeMeta: u.TypeMeta,
		ListMeta: *u.ListMeta.DeepCopy(),
	}
	for _, item := range u.Items {
		out.Items = append(out.Items, item.DeepCopy())
	}
	return out
}
